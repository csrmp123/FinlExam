// Clair Parsons
// Final Exam


// Trouble Areas:
// Connecting the actual api to the content


// creating a vue component to get started working with vue
Vue.component('theQuote', {
    props: ['id', 'name'],
    api: "https://quote-garden.herokuapp.com/api/v3/quotes&{author}", // Making this a constant so I dont have to retype it all later
 // this array is containing the id of the quotes and will later display the authors name as well
    template: '<span>{{name}}, {{id}}</span>' // this template will make sure tha the data displays on the UI
});

new Vue({ // new Vue, this will connect to my main div, which is app in the html doc
    el: '#app', // main div
    data: { // my displayed data
        quotes: [ // this is where the quotes play a role. it is under and array. The names and the quotes will all be together, but I want the different authors to be separate
            {
                id: author, // creating an id
                quoteText: '', // this will be my author's name
                quoteAuthor: 'Bill Gates' // this will be the displayed code
            }
        ]
    }
});



new Vue({ // new Vue, this will connect to my main div, which is app in the html doc
    el: '#app2', // main div
    data: { // my displayed data
        quotes: [ // this is where the quotes play a role. it is under and array. The names and the quotes will all be together, but I want the different authors to be separate
            {
                id: author, // creating an id
                quoteText: '', // this will be my author's name
                quoteAuthor: 'Bill Gates' // this will be the displayed code
            }
            
        ]
    }
});




new Vue({ // new Vue, this will connect to my main div, which is app in the html doc
    el: '#app3', // main div
    data: { // my displayed data
        quotes: [ // this is where the quotes play a role. it is under and array. The names and the quotes will all be together, but I want the different authors to be separate
            {
                id: author, // creating an id
                quoteText: '', // this will be my author's name
                quoteAuthor: 'Bill Gates' // this will be the displayed code
            }
           
        ]
    }
});