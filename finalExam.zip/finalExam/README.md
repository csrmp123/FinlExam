Thank you for being such an amazing teacher!
I have learned so much and I will never forget the valuable lessons taught here